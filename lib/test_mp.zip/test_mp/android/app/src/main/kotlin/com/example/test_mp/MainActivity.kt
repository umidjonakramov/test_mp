package com.example.test_mp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
