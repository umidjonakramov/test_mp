part of 'home_bloc.dart';

@immutable
abstract class HomeEvent {}

class HomeCategoryEvent extends HomeEvent{}
class HomeProductEvent extends HomeEvent{}

